syms x y;
func = x^2 + y^2 - 1;

disp(function_roots(func));